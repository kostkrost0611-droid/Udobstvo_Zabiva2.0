from flask import Flask, render_template, request

app = Flask(__name__)

professions = ['Инженер-механик', 'Инженер-строитель', 'Специалист по робототехнике', 'Биолог', 'Геолог', 'Врач',
               'Психолог', 'Физик-ядерщик', 'Специалист по жизнеобеспечению', 'Пилот космического корабля', 'Связист',
               'Метеоролог']


@app.route('/')
@app.route('/index')
def index():
    title = request.args.get('title', 'Подготовка к миссии')
    return render_template('base.html', title=title)


@app.route('/list_prof/<param>')
def list_prof(param):
    list_type = param

    return render_template('list_prof.html', title='Список профессий', professions=professions,
                           list_type=list_type)

@app.route('/training/<prof>')
def training(prof):
    prof_lower = prof.lower()
    is_engineering = 'инженер' in prof_lower or 'строитель' in prof_lower

    if is_engineering:
        training_title = "Инженерные тренажеры"
    else:
        training_title = "Научные симуляторы"

    return render_template('training.html', title=training_title, training_title=training_title,
                           profession=prof, is_engineering=is_engineering)


@app.route('/answer')
@app.route('/auto_answer')
def auto_answer():
    data = {
        'title': 'Анкета',
        'surname': 'Watney',
        'name': 'Mark',
        'education': 'высшее',
        'profession': 'астронавт',
        'sex': 'male',
        'motivation': 'Всегда мечтал побывать на Марсе!',
        'ready': 'True'
    }
    return render_template('auto_answer.html', **data)


if __name__ == '__main__':
    app.run()