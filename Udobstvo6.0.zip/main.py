from flask import Flask, render_template, request

app = Flask(__name__)

professions = ['Инженер-механик', 'Инженер-строитель', 'Специалист по робототехнике', 'Биолог', 'Геолог', 'Врач',
               'Психолог', 'Физик-ядерщик', 'Специалист по жизнеобеспечению', 'Пилот космического корабля', 'Связист',
               'Метеоролог']


@app.route('/')
@app.route('/index')
def index():
    title = request.args.get('title', 'Подготовка к миссии')
    return render_template('base.html', title=title)


@app.route('/list_prof/<param>')
def list_prof(param):
    list_type = param

    return render_template('list_prof.html', title='Список профессий', professions=professions,
                           list_type=list_type)


@app.route('/training/<prof>')
def training(prof):
    prof_lower = prof.lower()
    is_engineering = 'инженер' in prof_lower or 'строитель' in prof_lower

    if is_engineering:
        training_title = "Инженерные тренажеры"
    else:
        training_title = "Научные симуляторы"

    return render_template('training.html', title=training_title, training_title=training_title,
                           profession=prof, is_engineering=is_engineering)


@app.route('/answer')
@app.route('/auto_answer')
def auto_answer():
    data = {
        'title': 'Анкета',
        'surname': 'Watney',
        'name': 'Mark',
        'education': 'высшее',
        'profession': 'астронавт',
        'sex': 'male',
        'motivation': 'Всегда мечтал побывать на Марсе!',
        'ready': 'True'
    }
    return render_template('auto_answer.html', **data)


@app.route('/login')
def login():
    return render_template('login.html', title='Доступ к системам корабля')


@app.route('/distribution')
def distribution():
    astronauts = ['Zabiv Zabiv', 'Zabivov zabiv', 'Zabivnoi zabiv', 'Zabivnoi Zabivnoi']
    return render_template('distribution.html', title='Распределение по каютам', astronauts=astronauts)


@app.route('/table')
def table():
    sex = request.args.get('sex', 'male')
    age = request.args.get('age', 25)

    try:
        age = int(age)
    except ValueError:
        age = 25

    if sex == 'male':
        if age < 21:
            wall_color = '#87CEEB'
            color_name = 'Голубой'
        else:
            wall_color = '#4682B4'
            color_name = 'Синий'
    elif sex == 'female':
        if age < 21:
            wall_color = '#FFB6C1'
            color_name = 'Светло-розовый'
        else:
            wall_color = '#DB7093'
            color_name = 'Розовый'
    else:
        wall_color = '#D3D3D3'
        color_name = 'Серый'

    if age < 21:
        mars_image = 'mars_kid.png'
        image_alt = 'Марсианин-ребенок'
    else:
        mars_image = 'mars_adult.png'
        image_alt = 'Марсианин-взрослый'

    return render_template('table.html', title='Оформление каюты', sex=sex, age=age,
                           wall_color=wall_color, color_name=color_name, mars_image=mars_image, image_alt=image_alt)


if __name__ == '__main__':
    app.run()