from flask import Flask, render_template, request

app = Flask(__name__)

professions = ['Инженер-механик', 'Инженер-строитель', 'Специалист по робототехнике', 'Биолог', 'Геолог', 'Врач',
               'Психолог', 'Физик-ядерщик', 'Специалист по жизнеобеспечению', 'Пилот космического корабля', 'Связист',
               'Метеоролог']


@app.route('/')
@app.route('/index')
def index():
    title = request.args.get('title', 'Подготовка к миссии')
    return render_template('base.html', title=title)


@app.route('/list_prof/<param>')
def list_prof(param):
    list_type = param

    return render_template('list_prof.html', title='Список профессий', professions=professions,
                           list_type=list_type)


@app.route('/training/<prof>')
def training(prof):
    prof_lower = prof.lower()
    is_engineering = 'инженер' in prof_lower or 'строитель' in prof_lower

    if is_engineering:
        training_title = "Инженерные тренажеры"
    else:
        training_title = "Научные симуляторы"

    return render_template('training.html', title=training_title, training_title=training_title,
                           profession=prof, is_engineering=is_engineering)


@app.route('/answer')
@app.route('/auto_answer')
def auto_answer():
    # Словарь с данными анкеты
    data = {
        'title': 'Анкета',
        'surname': 'Watney',
        'name': 'Mark',
        'education': 'высшее',
        'profession': 'астронавт',
        'sex': 'male',
        'motivation': 'Всегда мечтал побывать на Марсе!',
        'ready': 'True'
    }
    return render_template('auto_answer.html', **data)


@app.route('/login')
def login():
    return render_template('login.html', title='Доступ к системам корабля')


@app.route('/distribution')
def distribution():
    # Список астронавтов (может быть любым)
    astronauts = ['Иванов Иван', 'Петров Петр', 'Сидоров Сидор', 'Кузнецова Анна', 'Смирнов Алексей']
    return render_template('distribution.html', title='Распределение по каютам', astronauts=astronauts)


# Вариант 2: Маршрут с параметрами в URL
@app.route('/table/<sex>/<int:age>')
def table_with_params(sex, age):
    # Определяем цвет стен в зависимости от пола и возраста
    if sex == 'male':
        if age < 21:
            wall_color = '#87CEEB'  # Голубой для мальчиков
            color_name = 'Голубой'
        else:
            wall_color = '#4682B4'  # Синий для мужчин
            color_name = 'Синий'
    elif sex == 'female':
        if age < 21:
            wall_color = '#FFB6C1'  # Светло-розовый для девочек
            color_name = 'Светло-розовый'
        else:
            wall_color = '#DB7093'  # Розовый для женщин
            color_name = 'Розовый'
    else:
        wall_color = '#D3D3D3'  # Серый для других
        color_name = 'Серый'

    # Определяем картинку марсианина в зависимости от возраста
    if age < 21:
        mars_image = 'mars_kid.png'
        image_alt = 'Марсианин-ребенок'
    else:
        mars_image = 'mars_adult.png'
        image_alt = 'Марсианин-взрослый'

    return render_template('table.html',
                           title='Оформление каюты',
                           sex=sex,
                           age=age,
                           wall_color=wall_color,
                           color_name=color_name,
                           mars_image=mars_image,
                           image_alt=image_alt)


# Оставляем также старый маршрут для совместимости
@app.route('/table')
def table():
    # Получаем параметры из адресной строки
    sex = request.args.get('sex', 'male')
    age = request.args.get('age', 25)

    # Преобразуем возраст в целое число
    try:
        age = int(age)
    except ValueError:
        age = 25

    # Определяем цвет стен в зависимости от пола и возраста
    if sex == 'male':
        if age < 21:
            wall_color = '#87CEEB'  # Голубой для мальчиков
            color_name = 'Голубой'
        else:
            wall_color = '#4682B4'  # Синий для мужчин
            color_name = 'Синий'
    elif sex == 'female':
        if age < 21:
            wall_color = '#FFB6C1'  # Светло-розовый для девочек
            color_name = 'Светло-розовый'
        else:
            wall_color = '#DB7093'  # Розовый для женщин
            color_name = 'Розовый'
    else:
        wall_color = '#D3D3D3'  # Серый для других
        color_name = 'Серый'

    # Определяем картинку марсианина в зависимости от возраста
    if age < 21:
        mars_image = 'mars_kid.png'
        image_alt = 'Марсианин-ребенок'
    else:
        mars_image = 'mars_adult.png'
        image_alt = 'Марсианин-взрослый'

    return render_template('table.html',
                           title='Оформление каюты',
                           sex=sex,
                           age=age,
                           wall_color=wall_color,
                           color_name=color_name,
                           mars_image=mars_image,
                           image_alt=image_alt)


if __name__ == '__main__':
    app.run()