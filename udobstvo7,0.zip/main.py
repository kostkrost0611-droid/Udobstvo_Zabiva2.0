from flask import Flask, render_template, request, redirect, url_for
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)

UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

professions = ['Инженер-механик', 'Инженер-строитель', 'Специалист по робототехнике', 'Биолог', 'Геолог', 'Врач',
               'Психолог', 'Физик-ядерщик', 'Специалист по жизнеобеспечению', 'Пилот космического корабля', 'Связист',
               'Метеоролог']


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def get_gallery_images():
    images = []

    official_folder = 'static/images'
    if os.path.exists(official_folder):
        for filename in os.listdir(official_folder):
            if allowed_file(filename):
                images.append({
                    'filename': filename,
                    'path': 'images/' + filename,
                    'title': os.path.splitext(filename)[0].replace('_', ' ').title(),
                    'is_uploaded': False
                })

    if os.path.exists(app.config['UPLOAD_FOLDER']):
        for filename in os.listdir(app.config['UPLOAD_FOLDER']):
            if allowed_file(filename):
                name_without_ext = os.path.splitext(filename)[0]
                title = name_without_ext.replace('_', ' ').title()

                images.append({
                    'filename': filename,
                    'path': 'uploads/' + filename,
                    'title': title,
                    'is_uploaded': True
                })

    return images


@app.route('/')
@app.route('/index')
def index():
    title = request.args.get('title', 'Подготовка к миссии')
    return render_template('base.html', title=title)


@app.route('/list_prof/<param>')
def list_prof(param):
    list_type = param
    return render_template('list_prof.html', title='Список профессий', professions=professions,
                           list_type=list_type)


@app.route('/training/<prof>')
def training(prof):
    prof_lower = prof.lower()
    is_engineering = 'инженер' in prof_lower or 'строитель' in prof_lower
    if is_engineering:
        training_title = "Инженерные тренажеры"
    else:
        training_title = "Научные симуляторы"
    return render_template('training.html', title=training_title, training_title=training_title,
                           profession=prof, is_engineering=is_engineering)


@app.route('/answer')
@app.route('/auto_answer')
def auto_answer():
    data = {
        'title': 'Анкета',
        'surname': 'Watney',
        'name': 'Mark',
        'education': 'высшее',
        'profession': 'астронавт',
        'sex': 'male',
        'motivation': 'Всегда мечтал побывать на Марсе!',
        'ready': 'True'
    }
    return render_template('auto_answer.html', **data)


@app.route('/login')
def login():
    return render_template('login.html', title='Доступ к системам корабля')


@app.route('/distribution')
def distribution():
    astronauts = ['Иванов Иван', 'Петров Петр', 'Сидоров Сидор', 'Кузнецова Анна', 'Смирнов Алексей']
    return render_template('distribution.html', title='Распределение по каютам', astronauts=astronauts)


@app.route('/table/<sex>/<int:age>')
def table_with_params(sex, age):
    if sex == 'male':
        if age < 21:
            wall_color = '#87CEEB'
            color_name = 'Голубой'
        else:
            wall_color = '#4682B4'
            color_name = 'Синий'
    elif sex == 'female':
        if age < 21:
            wall_color = '#FFB6C1'
            color_name = 'Светло-розовый'
        else:
            wall_color = '#DB7093'
            color_name = 'Розовый'
    else:
        wall_color = '#D3D3D3'
        color_name = 'Серый'

    if age < 21:
        mars_image = 'mars_kid.png'
        image_alt = 'Марсианин-ребенок'
    else:
        mars_image = 'mars_adult.png'
        image_alt = 'Марсианин-взрослый'

    return render_template('table.html',
                           title='Оформление каюты',
                           sex=sex,
                           age=age,
                           wall_color=wall_color,
                           color_name=color_name,
                           mars_image=mars_image,
                           image_alt=image_alt)


@app.route('/table')
def table():
    sex = request.args.get('sex', 'male')
    age = request.args.get('age', 25)
    try:
        age = int(age)
    except ValueError:
        age = 25

    if sex == 'male':
        if age < 21:
            wall_color = '#87CEEB'
            color_name = 'Голубой'
        else:
            wall_color = '#4682B4'
            color_name = 'Синий'
    elif sex == 'female':
        if age < 21:
            wall_color = '#FFB6C1'
            color_name = 'Светло-розовый'
        else:
            wall_color = '#DB7093'
            color_name = 'Розовый'
    else:
        wall_color = '#D3D3D3'
        color_name = 'Серый'

    if age < 21:
        mars_image = 'mars_kid.png'
        image_alt = 'Марсианин-ребенок'
    else:
        mars_image = 'mars_adult.png'
        image_alt = 'Марсианин-взрослый'

    return render_template('table.html',
                           title='Оформление каюты',
                           sex=sex,
                           age=age,
                           wall_color=wall_color,
                           color_name=color_name,
                           mars_image=mars_image,
                           image_alt=image_alt)


@app.route('/gallery')
def gallery():
    images = get_gallery_images()
    return render_template('gallery.html', title='Марсианская галерея', images=images)


@app.route('/upload', methods=['POST'])
def upload_image():
    if 'image' not in request.files:
        return redirect(url_for('gallery'))

    file = request.files['image']
    title = request.form.get('title', '')

    if file.filename == '':
        return redirect(url_for('gallery'))

    if file and allowed_file(file.filename):
        ext = os.path.splitext(file.filename)[1]

        if title:
            new_filename = secure_filename(title.replace(' ', '_')) + ext
        else:
            new_filename = secure_filename(file.filename)

        filepath = os.path.join(app.config['UPLOAD_FOLDER'], new_filename)
        file.save(filepath)

    return redirect(url_for('gallery'))


if __name__ == '__main__':
    app.run(debug=True)